class Node {
	public:
		Node *neighbors;
		float x;
		float y;
		float z;
};